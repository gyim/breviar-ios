==========================
HTML2TXT 4.0 README
==========================

HTML2TXT is a software tool to convert html documents into text format. It not only remove the tags, but also reformat the text to get a more readable result.

==================================
What's new in HTML2TXT 4.0?
==================================
Support add files in sub folders.
FIxed some bugs.
Speed Increased.
Improved interface.

==================================
Enhanced Version
==================================
HTML2TXT has a command line version and a dll version.
With a command line version, you can specify the input and output files in command parameter.
A dll version is also included, which has a function named "html2txt" in it. You can use this function in you own program to perform the conversation.
More infomation on how to get the enhanced version, please visit http://www.bobsoft.com/order.php?p=h2t

==================================
HTML2TXT Main Features
==================================
The program has been completely rewritten, and now produces much better results when converting HTML files into text files.
Proccess thousands files in a minute.
Convert multi-files in one time.
HTML2TXT is a freeware so that you can use it for free.
Enhanced versions with more great features available to purchace.
And even more...

==================================
Contact us by E-mail 
==================================
Any comments about our program are welcome. We will make it better with your help. 

webmaster@bobsoft.com
Our products are distributed via internet. If you have a website similar with this one, and want to exchange a link with us, please send message to us use this email. 

support@bobsoft.com
If you encounter any problems in using of our products, you may email us. 
If you find bugs during using, please report to us via this email, we are really appreciate your time. 

sales@bobsoft.com
Want to buy our products or to know more about details before buying them? Send E-mail to us right now. 

BobSoft.com
July,2004